package ms.docker.jasper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasperReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
